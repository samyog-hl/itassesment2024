document.addEventListener("DOMContentLoaded", function () {
  document.body.classList.add("fade-transition");
  const anchors = document.querySelectorAll("a[href]");
  for (const anchor of anchors) {
    anchor.addEventListener("click", function (e) {
      const url = anchor.getAttribute("href");
      if (url.startsWith("#") || anchor.target === "_blank") return;
      e.preventDefault();
      
    document.body.classList.add("fade-out");
    document.querySelectorAll(".no-fade").forEach(el => el.classList.add("no-transition"));
    
      setTimeout(() => {
        window.location.href = url;
      }, 300);
    });
  }
});